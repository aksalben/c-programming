#include<stdio.h>
int main()
{
 int x=10;
 if(x>0)
    x++;
 printf("\n x=%d\n",x);
 return 0;
 }
