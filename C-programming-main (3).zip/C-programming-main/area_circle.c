#include<stdio.h>
int main()
{
 float radius,area;
 printf("\nEnter the radius:");
 scanf("%f",&radius);
 area=3.14*radius*radius;
 printf("\nArea =%f",area);
 return 0;
}
